# fgrep

> هذا الأمر هو اسم مستعار لـ `grep --fixed-strings`.

- إعرض التوثيقات للأمر الأصلي:

`tldr grep`

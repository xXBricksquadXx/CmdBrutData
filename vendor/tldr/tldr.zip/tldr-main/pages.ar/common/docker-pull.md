# docker pull

> هذا الأمر هو اسم مستعار لـ `docker image pull`.

- إعرض التوثيقات للأمر الأصلي:

`tldr docker image pull`

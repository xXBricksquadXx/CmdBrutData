# pnmtopnm

> هذا الأمر هو اسم مستعار لـ `pamtopnm`.

- إعرض التوثيقات للأمر الأصلي:

`tldr pamtopnm`

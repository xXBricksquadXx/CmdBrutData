# tlmgr arch

> هذا الأمر هو اسم مستعار لـ `tlmgr platform`.

- إعرض التوثيقات للأمر الأصلي:

`tldr tlmgr platform`

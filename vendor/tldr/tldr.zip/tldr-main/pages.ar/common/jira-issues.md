# jira issues

> هذا الأمر هو اسم مستعار لـ `jira issue`.

- إعرض التوثيقات للأمر الأصلي:

`tldr jira issue`

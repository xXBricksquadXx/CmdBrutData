# bzcat

> هذا الأمر هو اسم مستعار لـ `bzip2 --decompress --stdout`.

- إعرض التوثيقات للأمر الأصلي:

`tldr bzip2`

# docker update

> هذا الأمر هو اسم مستعار لـ `docker container update`.

- إعرض التوثيقات للأمر الأصلي:

`tldr docker container update`

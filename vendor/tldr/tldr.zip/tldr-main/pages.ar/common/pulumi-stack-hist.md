# pulumi stack hist

> هذا الأمر هو اسم مستعار لـ `pulumi stack history`.

- إعرض التوثيقات للأمر الأصلي:

`tldr pulumi stack history`

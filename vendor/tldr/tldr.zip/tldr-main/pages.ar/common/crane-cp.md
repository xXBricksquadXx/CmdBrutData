# crane cp

> هذا الأمر هو اسم مستعار لـ `crane copy`.

- إعرض التوثيقات للأمر الأصلي:

`tldr crane copy`

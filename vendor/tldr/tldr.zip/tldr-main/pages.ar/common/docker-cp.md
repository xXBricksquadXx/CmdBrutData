# docker cp

> هذا الأمر هو اسم مستعار لـ `docker container cp`.

- إعرض التوثيقات للأمر الأصلي:

`tldr docker container cp`

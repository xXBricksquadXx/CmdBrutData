# docker diff

> هذا الأمر هو اسم مستعار لـ `docker container diff`.

- إعرض التوثيقات للأمر الأصلي:

`tldr docker container diff`

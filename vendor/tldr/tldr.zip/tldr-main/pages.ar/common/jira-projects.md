# jira projects

> هذا الأمر هو اسم مستعار لـ `jira project`.

- إعرض التوثيقات للأمر الأصلي:

`tldr jira project`

# docker container rm

> هذا الأمر هو اسم مستعار لـ `docker rm`.
> لمزيد من التفاصيل: <https://docs.docker.com/reference/cli/docker/container/rm/>.

- إعرض التوثيقات للأمر الأصلي:

`tldr docker rm`

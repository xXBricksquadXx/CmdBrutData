# npm-rb

> هذا الأمر هو اسم مستعار لـ `npm-rebuild`.

- إعرض التوثيقات للأمر الأصلي:

`tldr npm-rebuild`

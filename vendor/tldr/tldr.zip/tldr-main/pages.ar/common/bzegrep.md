# bzegrep

> هذا الأمر هو اسم مستعار لـ `bzgrep --extended-regexp`.

- إعرض التوثيقات للأمر الأصلي:

`tldr bzgrep`

# bzfgrep

> هذا الأمر هو اسم مستعار لـ `bzgrep --fixed-strings`.

- إعرض التوثيقات للأمر الأصلي:

`tldr bzgrep`

# impacket-smbclient

> هذا الأمر هو اسم مستعار لـ `smbclient.py`.

- إعرض التوثيقات للأمر الأصلي:

`tldr smbclient.py`

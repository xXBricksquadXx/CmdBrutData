# kite

> هذا الأمر هو اسم مستعار لـ `kiterunner`.

- إعرض التوثيقات للأمر الأصلي:

`tldr kiterunner`

# impacket-psexec

> هذا الأمر هو اسم مستعار لـ `psexec.py`.

- إعرض التوثيقات للأمر الأصلي:

`tldr psexec.py`

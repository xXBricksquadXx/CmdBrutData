# docker stats

> هذا الأمر هو اسم مستعار لـ `docker container stats`.

- إعرض التوثيقات للأمر الأصلي:

`tldr docker container stats`

# typeset

> هذا الأمر هو اسم مستعار لـ `declare`.

- إعرض التوثيقات للأمر الأصلي:

`tldr declare`

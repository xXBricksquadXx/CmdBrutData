# docker run

> هذا الأمر هو اسم مستعار لـ `docker container run`.

- إعرض التوثيقات للأمر الأصلي:

`tldr docker container run`

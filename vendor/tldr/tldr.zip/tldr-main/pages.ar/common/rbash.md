# rbash

> هذا الأمر هو اسم مستعار لـ `bash --restricted`.

- إعرض التوثيقات للأمر الأصلي:

`tldr bash`

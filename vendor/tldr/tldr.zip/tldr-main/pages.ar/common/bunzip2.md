# bunzip2

> هذا الأمر هو اسم مستعار لـ `bzip2 --decompress`.

- إعرض التوثيقات للأمر الأصلي:

`tldr bzip2`

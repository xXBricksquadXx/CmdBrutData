# npm restart

> هذا الأمر هو اسم مستعار لـ `npm run restart`.

- إعرض التوثيقات للأمر الأصلي:

`tldr npm run`

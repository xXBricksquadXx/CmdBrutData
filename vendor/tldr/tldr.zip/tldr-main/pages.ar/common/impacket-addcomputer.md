# impacket-addcomputer

> هذا الأمر هو اسم مستعار لـ `addcomputer.py`.

- إعرض التوثيقات للأمر الأصلي:

`tldr addcomputer.py`

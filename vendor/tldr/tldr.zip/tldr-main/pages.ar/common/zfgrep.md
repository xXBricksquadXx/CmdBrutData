# zfgrep

> هذا الأمر هو اسم مستعار لـ `zgrep --fixed-strings`.

- إعرض التوثيقات للأمر الأصلي:

`tldr zgrep`

# xzcat

> هذا الأمر هو اسم مستعار لـ `xz --decompress --stdout`.

- إعرض التوثيقات للأمر الأصلي:

`tldr xz`

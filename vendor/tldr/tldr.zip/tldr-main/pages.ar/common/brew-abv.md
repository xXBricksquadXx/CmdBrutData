# brew abv

> هذا الأمر هو اسم مستعار لـ `brew info`.

- إعرض التوثيقات للأمر الأصلي:

`tldr brew info`

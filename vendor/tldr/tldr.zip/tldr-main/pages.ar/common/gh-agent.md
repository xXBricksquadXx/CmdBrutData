# gh agent

> هذا الأمر هو اسم مستعار لـ `gh agent-task`.

- إعرض التوثيقات للأمر الأصلي:

`tldr gh agent-task`

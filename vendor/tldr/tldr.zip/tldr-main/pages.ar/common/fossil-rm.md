# fossil rm

> هذا الأمر هو اسم مستعار لـ `fossil delete`.

- إعرض التوثيقات للأمر الأصلي:

`tldr fossil delete`

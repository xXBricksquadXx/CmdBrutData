# arch

> هذا الأمر هو اسم مستعار لـ `uname --machine`.

- إعرض التوثيقات للأمر الأصلي:

`tldr uname`

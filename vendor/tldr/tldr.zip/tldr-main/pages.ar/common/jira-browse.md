# jira browse

> هذا الأمر هو اسم مستعار لـ `jira open`.

- إعرض التوثيقات للأمر الأصلي:

`tldr jira open`

# gh cs

> هذا الأمر هو اسم مستعار لـ `gh codespace`.

- إعرض التوثيقات للأمر الأصلي:

`tldr gh codespace`

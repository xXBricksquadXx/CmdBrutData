# lzegrep

> هذا الأمر هو اسم مستعار لـ `xzgrep --extended-regexp`.

- إعرض التوثيقات للأمر الأصلي:

`tldr xzgrep`

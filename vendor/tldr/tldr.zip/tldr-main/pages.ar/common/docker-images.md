# docker images

> هذا الأمر هو اسم مستعار لـ `docker image ls`.

- إعرض التوثيقات للأمر الأصلي:

`tldr docker image ls`

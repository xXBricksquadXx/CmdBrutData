# impacket-secretsdump

> هذا الأمر هو اسم مستعار لـ `secretsdump.py`.

- إعرض التوثيقات للأمر الأصلي:

`tldr secretsdump.py`

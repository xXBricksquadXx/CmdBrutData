# fossil forget

> هذا الأمر هو اسم مستعار لـ `fossil rm`.
> لمزيد من التفاصيل: <https://fossil-scm.org/home/help/forget>.

- إعرض التوثيقات للأمر الأصلي:

`tldr fossil rm`

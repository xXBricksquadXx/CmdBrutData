# impacket-mssqlclient

> هذا الأمر هو اسم مستعار لـ `mssqlclient.py`.

- إعرض التوثيقات للأمر الأصلي:

`tldr mssqlclient.py`

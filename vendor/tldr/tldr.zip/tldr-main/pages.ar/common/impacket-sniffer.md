# impacket-sniffer

> هذا الأمر هو اسم مستعار لـ `sniffer.py`.

- إعرض التوثيقات للأمر الأصلي:

`tldr sniffer.py`

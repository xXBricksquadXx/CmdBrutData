# docker logs

> هذا الأمر هو اسم مستعار لـ `docker container logs`.

- إعرض التوثيقات للأمر الأصلي:

`tldr docker container logs`

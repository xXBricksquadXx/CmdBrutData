# npm it

> هذا الأمر هو اسم مستعار لـ `npm install-test`.

- إعرض التوثيقات للأمر الأصلي:

`tldr npm install-test`

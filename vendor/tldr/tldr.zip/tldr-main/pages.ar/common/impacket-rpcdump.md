# impacket-rpcdump

> هذا الأمر هو اسم مستعار لـ `rpcdump.py`.

- إعرض التوثيقات للأمر الأصلي:

`tldr rpcdump.py`

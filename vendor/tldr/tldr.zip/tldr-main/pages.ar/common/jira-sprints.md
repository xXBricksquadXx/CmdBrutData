# jira sprints

> هذا الأمر هو اسم مستعار لـ `jira sprint`.

- إعرض التوثيقات للأمر الأصلي:

`tldr jira sprint`

# gh rs

> هذا الأمر هو اسم مستعار لـ `gh ruleset`.

- إعرض التوثيقات للأمر الأصلي:

`tldr gh ruleset`

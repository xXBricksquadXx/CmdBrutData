# rustup uninstall

> هذا الأمر هو اسم مستعار لـ `rustup toolchain uninstall`.

- إعرض التوثيقات للأمر الأصلي:

`tldr rustup toolchain`

# bun i

> هذا الأمر هو اسم مستعار لـ `bun install`.

- إعرض التوثيقات للأمر الأصلي:

`tldr bun install`

# impacket-smbserver

> هذا الأمر هو اسم مستعار لـ `smbserver.py`.

- إعرض التوثيقات للأمر الأصلي:

`tldr smbserver.py`

# npm test

> هذا الأمر هو اسم مستعار لـ `npm run test`.

- إعرض التوثيقات للأمر الأصلي:

`tldr npm run`

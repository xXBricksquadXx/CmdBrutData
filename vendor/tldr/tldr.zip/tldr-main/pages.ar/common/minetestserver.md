# minetestserver

> هذا الأمر هو اسم مستعار لـ `luantiserver`.

- إعرض التوثيقات للأمر الأصلي:

`tldr luantiserver`

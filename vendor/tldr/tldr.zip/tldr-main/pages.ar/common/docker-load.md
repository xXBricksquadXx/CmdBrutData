# docker load

> هذا الأمر هو اسم مستعار لـ `docker image load`.

- إعرض التوثيقات للأمر الأصلي:

`tldr docker image load`

# ug

> هذا الأمر هو اسم مستعار لـ `ugrep --config --pretty --sort`.

- إعرض التوثيقات للأمر الأصلي:

`tldr ugrep`

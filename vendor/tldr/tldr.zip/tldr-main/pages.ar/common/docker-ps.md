# docker ps

> هذا الأمر هو اسم مستعار لـ `docker container ls`.

- إعرض التوثيقات للأمر الأصلي:

`tldr docker container ls`

# mogrify

> هذا الأمر هو اسم مستعار لـ `magick mogrify`.

- إعرض التوثيقات للأمر الأصلي:

`tldr magick mogrify`

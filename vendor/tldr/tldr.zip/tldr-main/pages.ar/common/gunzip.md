# gunzip

> هذا الأمر هو اسم مستعار لـ `gzip --decompress`.

- إعرض التوثيقات للأمر الأصلي:

`tldr gzip`

# clist

> هذا الأمر هو اسم مستعار لـ `choco list`.

- إعرض التوثيقات للأمر الأصلي:

`tldr choco list`

# sls

> هذا الأمر هو اسم مستعار لـ `Select-String`.

- إعرض التوثيقات للأمر الأصلي:

`tldr select-string`

# cuninst

> هذا الأمر هو اسم مستعار لـ `choco uninstall`.

- إعرض التوثيقات للأمر الأصلي:

`tldr choco uninstall`

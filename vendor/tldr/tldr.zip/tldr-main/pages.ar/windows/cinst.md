# cinst

> هذا الأمر هو اسم مستعار لـ `choco install`.

- إعرض التوثيقات للأمر الأصلي:

`tldr choco install`

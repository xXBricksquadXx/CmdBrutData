# rni

> هذا الأمر هو اسم مستعار لـ `Rename-Item`.

- إعرض التوثيقات للأمر الأصلي:

`tldr Rename-Item`

# bleachbit

> هذا الأمر هو اسم مستعار لـ `bleachbit_console`.

- إعرض التوثيقات للأمر الأصلي:

`tldr bleachbit_console`

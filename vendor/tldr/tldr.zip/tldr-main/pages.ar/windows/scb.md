# scb

> هذا الأمر هو اسم مستعار لـ `Set-Clipboard`.

- إعرض التوثيقات للأمر الأصلي:

`tldr Set-Clipboard`

# lrunzip

> هذا الأمر هو اسم مستعار لـ `lrzip --decompress`.

- إعرض التوثيقات للأمر الأصلي:

`tldr lrzip`

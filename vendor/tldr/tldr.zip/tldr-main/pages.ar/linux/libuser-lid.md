# libuser-lid

> هذا الأمر هو اسم مستعار لـ `lid`.

- إعرض التوثيقات للأمر الأصلي:

`tldr lid.libuser`

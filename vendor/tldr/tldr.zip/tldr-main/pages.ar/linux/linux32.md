# linux32

> هذا الأمر هو اسم مستعار لـ `setarch linux32`.

- إعرض التوثيقات للأمر الأصلي:

`tldr setarch`

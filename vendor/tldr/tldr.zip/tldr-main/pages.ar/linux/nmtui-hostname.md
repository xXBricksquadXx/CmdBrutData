# nmtui-hostname

> هذا الأمر هو اسم مستعار لـ `nmtui hostname`.

- إعرض التوثيقات للأمر الأصلي:

`tldr nmtui`

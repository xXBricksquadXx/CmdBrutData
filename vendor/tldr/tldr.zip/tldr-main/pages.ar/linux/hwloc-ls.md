# hwloc-ls

> هذا الأمر هو اسم مستعار لـ `lstopo-no-graphics`.

- إعرض التوثيقات للأمر الأصلي:

`tldr lstopo-no-graphics`

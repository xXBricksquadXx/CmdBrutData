# pacman -R

> هذا الأمر هو اسم مستعار لـ `pacman --remove`.

- إعرض التوثيقات للأمر الأصلي:

`tldr pacman remove`

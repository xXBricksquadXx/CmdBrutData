# apt-add-repository

> هذا الأمر هو اسم مستعار لـ `add-apt-repository`.

- إعرض التوثيقات للأمر الأصلي:

`tldr add-apt-repository`

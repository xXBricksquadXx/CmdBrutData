# rkhunter

> يبحث عن برامج روتكيت والبرمجيات الخبيثة.
> لمزيد من التفاصيل: <https://manned.org/rkhunter>.

- فحص النظام للبحث عن برامج روتكيت والبرمجيات الخبيثة:

`sudo rkhunter --check`

- تحديث rkhunter:

`sudo rkhunter --update`

- عرض جميع الاختبارات المتاحة:

`sudo rkhunter --list`

- عرض الإصدار:

`sudo rkhunter --versioncheck`

- عرض المساعدة:

`sudo rkhunter --help`

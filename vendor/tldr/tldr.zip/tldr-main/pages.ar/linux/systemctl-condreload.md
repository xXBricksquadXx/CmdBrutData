# systemctl condreload

> هذا الأمر هو اسم مستعار لـ `systemctl try-reload-or-restart`.

- إعرض التوثيقات للأمر الأصلي:

`tldr systemctl try-reload-or-restart`

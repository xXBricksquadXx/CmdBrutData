# update-grub

> هذا الأمر هو اسم مستعار لـ `grub-mkconfig --output /boot/grub/grub.cfg`.

- إعرض التوثيقات للأمر الأصلي:

`tldr grub-mkconfig`

# pacman -U

> هذا الأمر هو اسم مستعار لـ `pacman --upgrade`.

- إعرض التوثيقات للأمر الأصلي:

`tldr pacman upgrade`

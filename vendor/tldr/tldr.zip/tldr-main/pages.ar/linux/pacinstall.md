# pacinstall

> هذا الأمر هو اسم مستعار لـ `pactrans --install`.

- إعرض التوثيقات للأمر الأصلي:

`tldr pactrans`

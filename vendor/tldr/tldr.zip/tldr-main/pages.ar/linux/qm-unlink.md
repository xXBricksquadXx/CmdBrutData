# qm unlink

> هذا الأمر هو اسم مستعار لـ `qm disk unlink`.

- إعرض التوثيقات للأمر الأصلي:

`tldr qm disk unlink`

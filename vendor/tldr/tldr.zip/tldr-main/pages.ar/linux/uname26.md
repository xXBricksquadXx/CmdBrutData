# uname26

> هذا الأمر هو اسم مستعار لـ `setarch uname26`.

- إعرض التوثيقات للأمر الأصلي:

`tldr setarch`

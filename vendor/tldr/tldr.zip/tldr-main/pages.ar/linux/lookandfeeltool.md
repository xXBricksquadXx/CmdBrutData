# lookandfeeltool

> هذا الأمر هو اسم مستعار لـ `plasma-apply-lookandfeel`.

- إعرض التوثيقات للأمر الأصلي:

`tldr plasma-apply-lookandfeel`

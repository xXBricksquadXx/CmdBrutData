# steamos-boot-install

> هذا الأمر هو اسم مستعار لـ `steamos-finalize-install`.

- إعرض التوثيقات للأمر الأصلي:

`tldr steamos-finalize-install`

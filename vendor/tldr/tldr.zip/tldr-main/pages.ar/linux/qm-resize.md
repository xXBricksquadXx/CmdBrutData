# qm resize

> هذا الأمر هو اسم مستعار لـ `qm disk resize`.

- إعرض التوثيقات للأمر الأصلي:

`tldr qm disk resize`

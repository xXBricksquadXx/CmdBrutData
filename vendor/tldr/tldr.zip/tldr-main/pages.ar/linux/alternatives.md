# alternatives

> هذا الأمر هو اسم مستعار لـ `update-alternatives`.

- إعرض التوثيقات للأمر الأصلي:

`tldr update-alternatives`

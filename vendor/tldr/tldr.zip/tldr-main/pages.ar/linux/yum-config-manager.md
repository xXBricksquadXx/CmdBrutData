# yum config-manager

> هذا الأمر هو اسم مستعار لـ `dnf config-manager`.

- إعرض التوثيقات للأمر الأصلي:

`tldr dnf config-manager`

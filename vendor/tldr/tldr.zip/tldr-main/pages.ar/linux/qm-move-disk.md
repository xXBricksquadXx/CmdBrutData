# qm move-disk

> هذا الأمر هو اسم مستعار لـ `qm disk move`.

- إعرض التوثيقات للأمر الأصلي:

`tldr qm disk move`

# file-rename

> এই কমান্ডটি `rename` - এর একটি উপনাম।

- মূল কমান্ডের ডকুমেন্টেশন দেখুন:

`tldr {{[-p|--platform]}} common rename`

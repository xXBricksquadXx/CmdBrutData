# fgrep

> এই কমান্ডটি `grep --fixed-strings` - এর একটি উপনাম।

- মূল কমান্ডের ডকুমেন্টেশন দেখুন:

`tldr grep`

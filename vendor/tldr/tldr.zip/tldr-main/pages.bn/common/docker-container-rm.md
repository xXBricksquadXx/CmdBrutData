# docker container rm

> এই কমান্ডটি `docker rm` - এর একটি উপনাম।
> আরও তথ্য পাবেন: <https://docs.docker.com/reference/cli/docker/container/rm/>।

- মূল কমান্ডের ডকুমেন্টেশন দেখুন:

`tldr docker rm`

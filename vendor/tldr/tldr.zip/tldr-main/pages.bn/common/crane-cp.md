# crane cp

> এই কমান্ডটি `crane copy` - এর একটি উপনাম।

- মূল কমান্ডের ডকুমেন্টেশন দেখুন:

`tldr crane copy`

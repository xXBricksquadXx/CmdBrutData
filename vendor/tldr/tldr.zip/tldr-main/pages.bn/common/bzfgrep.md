# bzfgrep

> এই কমান্ডটি `bzgrep --fixed-strings` - এর একটি উপনাম।

- মূল কমান্ডের ডকুমেন্টেশন দেখুন:

`tldr bzgrep`

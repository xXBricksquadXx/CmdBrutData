# docker ps

> এই কমান্ডটি `docker container ls` - এর একটি উপনাম।

- মূল কমান্ডের ডকুমেন্টেশন দেখুন:

`tldr docker container ls`

# bun c

> এই কমান্ডটি `bun create` - এর একটি উপনাম।

- মূল কমান্ডের ডকুমেন্টেশন দেখুন:

`tldr bun create`

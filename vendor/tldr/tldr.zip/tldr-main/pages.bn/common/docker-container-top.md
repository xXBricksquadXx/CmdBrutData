# docker container top

> এই কমান্ডটি `docker top` - এর একটি উপনাম।
> আরও তথ্য পাবেন: <https://docs.docker.com/reference/cli/docker/container/top/>।

- মূল কমান্ডের ডকুমেন্টেশন দেখুন:

`tldr docker top`

# fossil new

> এই কমান্ডটি `fossil init` - এর একটি উপনাম।

- মূল কমান্ডের ডকুমেন্টেশন দেখুন:

`tldr fossil init`
